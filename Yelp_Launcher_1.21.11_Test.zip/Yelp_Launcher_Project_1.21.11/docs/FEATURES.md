# Yelp Launcher feature inventory

## First UI milestone
- Original navy/teal interface and responsive layout
- English only
- Installations/version library screen (sample data only)
- Mod catalogue screen (sample data only)
- 25 pack-category browser (categories only, no copyrighted pack payloads)
- World vault preview
- Settings categories: renderer, controls, Java, downloads, storage, Microsoft account, experiments, language and community
- Discord community link: https://discord.gg/J2YU63MFa

## Native launcher milestones
- Official Microsoft login and Minecraft ownership validation
- Official version manifest and asset download/verification pipeline
- Per-install isolation and Java runtime selection
- Fabric, Forge, NeoForge and Quilt compatibility where supported by the selected game version and engine
- Modrinth and other approved provider APIs; dependency and loader compatibility checks
- Resource pack, shader and modpack management
- Storage Access Framework integration and world backups
- Touch controls, keyboard, mouse and controller input
- Renderer selection, thermal-aware performance presets and crash diagnosis
- Offline component manifest, integrity checking and repair

## Guardrails
- Never collect Microsoft passwords.
- Never bypass Minecraft ownership requirements.
- Never ship Minecraft proprietary files.
- Never install unverified executables/scripts from mods.
- Label unsupported versions, mods and renderers honestly.
