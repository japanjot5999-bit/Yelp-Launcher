# Engine integration plan

## Selected candidate

Evaluate **Amethyst Android** as a Java Edition engine foundation:

https://github.com/AngelAuraMC/Amethyst-Android

The upstream README describes support for Java Edition versions, Forge and Fabric; the documented quick build uses a recursive clone and `:app_pojavlauncher:assembleDebug`. It also describes prebuilt JRE artifacts and a source build path. The project states LGPLv3, while its dependency table lists separate licences and some items with unknown or all-rights-reserved terms. Therefore, do not copy or redistribute every dependency blindly.

## Integration work still required

1. Pin a reviewed upstream commit and initialise every submodule.
2. Audit all code, assets, native libraries and transitive licences.
3. Preserve notices, offer corresponding source and satisfy LGPL obligations for any distributed modified LGPL components.
4. Identify stable engine entry points for account selection, version installation, runtime configuration, game launch, input and crash callbacks.
5. Build a Yelp-owned Android navigation/UI layer without reproducing Amethyst or MJ Launcher branding.
6. Connect the UI to engine APIs using a narrow typed adapter; do not call upstream internals from WebView JavaScript.
7. Add device-specific ABI packaging (initially arm64-v8a, with other ABIs only if tested and needed).
8. Test Microsoft login, base game launch, controls, audio, renderer, suspend/resume, modded profiles and crash recovery on physical Android devices.

## Build command documented upstream

```sh
git clone --recursive https://github.com/AngelAuraMC/Amethyst-Android.git
cd Amethyst-Android
./gradlew :app_pojavlauncher:assembleDebug
```

The engine candidate is not vendored in this ZIP. The script in `../scripts/fetch-amethyst.sh` can fetch it for a later audit. Fetching upstream source is not the same as integrating it.
