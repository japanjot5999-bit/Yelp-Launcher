# Build and verification status — November 19, 2026

## Completed in this delivery
- Created a native Android Gradle project shell.
- Added a WebView Activity that loads the original UI from local app assets.
- Added internet permission for future online sign-in/download features.
- Routed external HTTPS links to the device browser.
- Bundled the English-only UI prototype and 25 pack-category catalogue.
- Added project, authentication, engine, offline-bundle and feature documentation.

## Checks performed
- Source files were written and inspected.
- The Gradle build was **not run** because the environment does not have Gradle or an Android SDK installed.
- No APK was produced.
- No Minecraft engine, JRE, renderer binary or OAuth implementation is included yet.

## Next engineering milestones
1. Fetch and audit the pinned Amethyst Android source and submodules.
2. Establish the native engine API and embed the engine under its licence obligations.
3. Implement Microsoft OAuth, Xbox/XSTS exchange and Minecraft ownership verification.
4. Implement version manifests, game file downloads and integrity checking.
5. Add runtime/renderer bundles by supported ABI; verify every component licence.
6. Implement mod/resource pack downloads with compatibility and author/source metadata.
7. Build, install and test on the target Android device.
8. Measure the real bundle size; only then decide whether a 600 MB+ offline expansion package is justified.


## Single-version test update — November 22, 2026
- Replaced demo version cards with one release profile: Minecraft Java Edition 1.21.11 (Vanilla).
- Added release date 9 December 2025 and Java 21 requirement.
- Added a clear profile-only status; the UI does not imply game files are installed.
- Mirrored web UI changes into Android bundled assets.
- Game files, Microsoft sign-in/ownership verification, Java runtime and game engine remain unimplemented; this build cannot launch Minecraft yet.
