# Offline-first bundle design

## Included in a future full distribution (only after licence review)

- Yelp Launcher native app and UI
- Required launcher-side Java runtimes, selected by Minecraft version
- Tested, redistributable graphics/rendering backends
- Native audio, input and compatibility libraries
- Architecture-specific binaries for explicitly supported ABIs
- Checksums, manifests, licence notices and source notices

## Not bundled

- Minecraft proprietary game JARs, assets or libraries that must be acquired through the official user entitlement flow
- Third-party mods, shaders, resource packs or modpacks without explicit distribution permission
- Dummy/padding files

## Packaging target

The requested 600 MB+ size is a target, not a requirement to waste storage. The actual package size must be measured after choosing supported ABIs, runtime versions, graphics backends and licences. Use an optional offline expansion archive if one APK would become too large or unmaintainable. The app should display a component manifest, total size, checksums and free-space estimate before installation.

## Device-specific strategy

Start with arm64-v8a because the target device is a modern Android phone. Add x86_64 or 32-bit ARM only when there is a tested user need; each extra ABI increases size. Keep downloaded Minecraft versions, mods, packs and user worlds outside the base APK.
