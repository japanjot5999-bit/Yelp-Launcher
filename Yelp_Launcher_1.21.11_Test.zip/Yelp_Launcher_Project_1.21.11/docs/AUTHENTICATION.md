# Microsoft account authentication requirements

Yelp Launcher must use official Microsoft account authentication. The user signs in on the Microsoft-hosted page using the browser/system authentication surface; Yelp Launcher must never request or store the Microsoft password.

Planned chain (to be implemented and tested against current official endpoints and app registration requirements):

1. Create a registered public/native client application and configure the exact redirect URI.
2. Start an OAuth authorization-code flow with PKCE using a system browser or supported authentication broker.
3. Validate the returned state and PKCE verifier; exchange the code using the registered public-client configuration.
4. Complete Xbox Live and XSTS authentication as required by Microsoft's current flow.
5. Exchange for a Minecraft Services access token.
6. Check the Minecraft profile and Java entitlement/ownership.
7. Store refresh credentials only using secure Android Keystore-backed storage; access tokens should be short-lived and never logged.
8. Refresh sessions safely; show actionable, distinct errors for consent, network, Xbox, XSTS, profile, entitlement, rate-limit and expired-session failures.
9. Provide sign-out and remove local tokens.

Do not embed a client secret in an APK. Do not claim authentication is implemented until the full end-to-end flow is tested with a legitimate Java Edition account. Authentication and ownership checks require an internet connection.
