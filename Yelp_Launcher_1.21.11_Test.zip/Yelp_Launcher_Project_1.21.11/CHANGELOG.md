# Changelog

## 0.2.0 — 2026-11-19
- Added native Android WebView shell and Gradle project structure.
- Packaged the original Yelp Launcher UI prototype as local Android assets.
- Updated sample installation labels so they are not presented as live/current version data.
- Added engine integration, Microsoft authentication, offline bundle and build-status documentation.
- Added a Gradle bootstrap helper.
- No APK or Minecraft runtime is included in this version.


## 0.3.0-test — Single-version test
- Replaced demo version entries with Minecraft Java Edition 1.21.11 only.
- Added Vanilla release profile information and Java 21 requirement.
- Added selection and profile information actions.
- Clearly labels the entry as a profile only; no game files or engine are included.
