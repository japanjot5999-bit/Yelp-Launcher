# Third-party notices

This Yelp Launcher starter archive contains the original Yelp UI source and an Android WebView shell. It does not include Amethyst source code, Minecraft game files, Java runtime archives, graphics libraries, third-party mods or resource-pack payloads.

Amethyst Android is referenced as a candidate integration dependency only. Its upstream project states that it is licensed under GNU LGPLv3 and lists dependencies with separate licences, including entries whose status is unknown or all-rights-reserved. Before building a redistributed launcher from it, review the upstream licence text, each submodule, all transitive/native dependencies and current redistribution terms. Preserve required notices and source availability.

Upstream reference: https://github.com/AngelAuraMC/Amethyst-Android
