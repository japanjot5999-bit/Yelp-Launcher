# Yelp Launcher Android Shell (0.1.0 prototype)

This is the first native Android project shell for Yelp Launcher. It packages the original English-only UI prototype inside an Android WebView and opens external HTTPS links (including the Yelp Discord invite) in the device browser.

## Important status

This is **not yet a playable Minecraft Java launcher**. The following are not implemented in this project yet:

- Amethyst/Java game-engine integration
- Official Microsoft + Xbox + Minecraft Services authentication and ownership verification
- Real Minecraft version manifest/download/install pipeline
- Real Modrinth/CurseForge source integration
- Java runtime bundles, graphics backends and native architecture libraries
- Android Storage Access Framework world/mod/resource-pack management
- Real crash reporting and performance telemetry

The UI deliberately labels sample entries and actions as prototypes. No account credentials are collected.

## Build with Android development tooling

Requirements: Android SDK Platform 36, JDK 17, Android Gradle Plugin 9.4.1, Gradle 9.6.0.

From this `android/` directory, run:

```sh
./gradlew assembleDebug
```

The included small bootstrap script uses an installed Gradle if available, otherwise it downloads Gradle 9.6.0 on first run (requires `curl` and `unzip`). It does not download the Android SDK; install Android SDK Platform 36 and configure `ANDROID_HOME`/`local.properties` first.

The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk` (the debug variant uses an application ID suffix, so the actual file is `app-debug.apk`).

This archive does not include the Android SDK or any Android build tools. Do not expect this source ZIP to install directly as an APK.

## Phone-only note

Termux alone does not automatically provide a complete Android SDK/NDK toolchain. Building on an Android phone may require substantial setup and may not be reliable on every device. The project source is prepared now; the native engine integration and tested APK are separate milestones.

## Security

The app only requests internet access at this stage. It does not ask for storage permissions, Microsoft credentials, or access to private files. Future sign-in should use the official browser-based Microsoft OAuth authorization-code flow with PKCE and securely store refresh tokens using Android Keystore-backed storage. Never put a Microsoft client secret in the APK.
