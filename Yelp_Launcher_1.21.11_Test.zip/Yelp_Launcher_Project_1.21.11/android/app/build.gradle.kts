plugins {
    id("com.android.application")
}

android {
    namespace = "com.yelp.launcher"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.yelp.launcher"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "0.3.0-test"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
