const CACHE='yelp-launcher-ui-v1';
const FILES=['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./assets/yelp-mark.svg'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES))));
self.addEventListener('fetch',event=>event.respondWith(caches.match(event.request).then(hit=>hit||fetch(event.request))));
