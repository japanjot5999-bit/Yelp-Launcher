# Native Android build roadmap

1. **UI shell:** complete as an original HTML/CSS/JS prototype and packaged Android WebView shell.
2. **Engine audit:** fetch and review Amethyst Android source and all submodules, dependency licences and binary redistribution terms.
3. **Engine integration:** embed the selected engine behind a typed native adapter; keep Yelp UI and branding original.
4. **Microsoft authentication:** use the official browser-based sign-in, Xbox/XSTS authentication, Minecraft profile and Java entitlement checks.
5. **Downloads:** implement official version metadata, verified downloads, per-install isolation and repair.
6. **Mods and packs:** integrate authorised provider APIs with version/loader/dependency validation and attribution.
7. **Offline bundle:** package only redistributable, architecture-compatible runtimes and native libraries. Measure actual size; aim for 600 MB+ only if real components justify it.
8. **Testing:** test on the target Android phone for login, launch, input, audio, rendering, thermals, crash recovery and storage safety.

The current Android shell is not a playable Minecraft launcher. See parent `docs/BUILD_STATUS.md` for exactly what has and has not been tested.
