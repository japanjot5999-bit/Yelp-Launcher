# Yelp Launcher feature scope

- Product name: Yelp Launcher
- Platform: Android phones first
- Language: English only
- Visual direction: original navy/teal/mint palette, library-first workspace, rounded cards and custom iconography; do not copy MJ Launcher screens or assets
- Community: https://discord.gg/J2YU63MFa

The UI preview represents a version library, mod catalogue, 25 resource-pack categories, world vault, community shortcut and advanced settings. All game/catalogue entries are sample data until native integrations are built.

The full product plan is in the parent `docs/FEATURES.md`.
