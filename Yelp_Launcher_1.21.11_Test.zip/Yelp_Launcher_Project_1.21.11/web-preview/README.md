# Yelp Launcher browser preview

Open `index.html` in a modern browser to preview the original English-only Yelp Launcher interface. This preview contains local sample data only. It does not perform Microsoft sign-in, download Minecraft files/mods/packs, access Android storage, or launch Java Edition.

For the native Android project, build requirements, engine plan and offline-first package strategy, see the parent folder's `README.md` and `docs/` directory.
