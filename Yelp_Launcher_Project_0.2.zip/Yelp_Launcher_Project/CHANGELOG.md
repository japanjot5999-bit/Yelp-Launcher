# Changelog

## 0.2.0 — 2026-11-19
- Added native Android WebView shell and Gradle project structure.
- Packaged the original Yelp Launcher UI prototype as local Android assets.
- Updated sample installation labels so they are not presented as live/current version data.
- Added engine integration, Microsoft authentication, offline bundle and build-status documentation.
- Added a Gradle bootstrap helper.
- No APK or Minecraft runtime is included in this version.
