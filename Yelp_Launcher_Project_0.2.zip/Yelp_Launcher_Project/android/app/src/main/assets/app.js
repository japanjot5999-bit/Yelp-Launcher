const pages = [...document.querySelectorAll('.page')];
const navItems = [...document.querySelectorAll('.nav-item')];
const toastEl = document.getElementById('toast');
let toastTimer;
function toast(message){toastEl.textContent=message;toastEl.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastEl.classList.remove('show'),2500)}
function showPage(name){pages.forEach(p=>p.classList.toggle('active',p.id===`page-${name}`));navItems.forEach(n=>n.classList.toggle('active',n.dataset.page===name));window.scrollTo({top:0,behavior:'smooth'});}
document.querySelectorAll('[data-page]').forEach(el=>el.addEventListener('click',()=>showPage(el.dataset.page)));

const versions=[
 {name:'Demo installation 1.21.x',kind:'release',loader:'Fabric',detail:'Performance profile · 8 sample mods',icon:'1.21'},
 {name:'Demo installation 1.21.x (clean)',kind:'release',loader:'Vanilla',detail:'Clean installation · no mods',icon:'1.21'},
 {name:'Demo installation 1.20.x',kind:'modded',loader:'Forge',detail:'Adventure collection · 14 sample mods',icon:'1.20'},
 {name:'Snapshot preview',kind:'snapshot',loader:'Vanilla',detail:'Experimental build · not installed',icon:'SNAP'}
];
const versionList=document.getElementById('version-list');
function renderVersions(){const term=document.getElementById('version-search').value.toLowerCase();const active=document.querySelector('#version-filters .filter.active')?.dataset.filter||'all';const filtered=versions.filter(v=>(active==='all'||(active==='modded'?v.loader!=='Vanilla':v.kind===active))&&(v.name+' '+v.loader+' '+v.detail).toLowerCase().includes(term));versionList.innerHTML=filtered.length?filtered.map((v,i)=>`<article class="list-card"><div class="list-icon">${v.icon}</div><div class="list-copy"><strong>${v.name}</strong><small>${v.loader} · ${v.detail}</small></div><button class="list-action" data-select-version="${versions.indexOf(v)}">SELECT</button></article>`).join(''):'<div class="empty-state"><h2>No matching versions</h2><p>Try another search or filter.</p></div>';versionList.querySelectorAll('[data-select-version]').forEach(b=>b.addEventListener('click',()=>{const v=versions[Number(b.dataset.selectVersion)];document.getElementById('home-version').textContent=v.name;document.getElementById('home-loader').textContent=v.loader+' · '+v.detail;toast('Selected '+v.name+' in the prototype.')}));}
document.getElementById('version-search').addEventListener('input',renderVersions);
document.querySelectorAll('#version-filters .filter').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('#version-filters .filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderVersions()}));
document.getElementById('add-version').addEventListener('click',()=>openDialog('Add a Minecraft version','The native version service will fetch the official version manifest, show available releases and snapshots, and download the selected files after compatibility checks. This prototype does not download game files. The names shown here are examples, not live available-version data.','OK'));
renderVersions();

const mods=[
 ['Sodium','Fabric','Rendering optimisation · sample listing'],['Lithium','Fabric','Game logic optimisation · sample listing'],['FerriteCore','Fabric / Forge','Memory use optimisation · sample listing'],['Mod Menu','Fabric','In-game mod list · sample listing'],['AppleSkin','Fabric / Forge','Food information overlay · sample listing'],['JEI','Forge / NeoForge','Item and recipe viewer · sample listing']
];
const modList=document.getElementById('mod-list');
function renderMods(){const term=document.getElementById('mod-search').value.toLowerCase();const items=mods.filter(m=>m.join(' ').toLowerCase().includes(term));modList.innerHTML=items.map((m,i)=>`<article class="list-card"><div class="list-icon">⌘</div><div class="list-copy"><strong>${m[0]}</strong><small>${m[1]} · ${m[2]}</small></div><button class="list-action" data-mod="${m[0]}">DETAILS</button></article>`).join('')||'<div class="empty-state"><h2>No sample mods found</h2><p>Try a different search term.</p></div>';modList.querySelectorAll('[data-mod]').forEach(b=>b.addEventListener('click',()=>openDialog(b.dataset.mod,'This is a sample catalogue entry, not a downloadable mod. The finished launcher will use source APIs and verify game version, loader, dependencies and licensing before installation.','UNDERSTOOD')))}
document.getElementById('mod-search').addEventListener('input',renderMods);renderMods();
document.getElementById('mod-filter').addEventListener('click',()=>toast('Advanced compatibility filters are planned for the native app.'));

const packNames=['Competitive Clean','Classic PvP','Bedwars Essentials','Skywars Essentials','16x Performance','32x Quality','Low-End FPS','Survival Plus',"Builder's Collection",'Redstone Toolkit','Parkour Collection','Adventure World','Medieval Fantasy','Modern City','Cartoon World','Vanilla Plus','Minimal HUD','Low Particles','Immersive Audio','Cinematic','Lightweight Shaders','Accessibility','High Contrast','Controller HUD','Tablet Interface'];
const packGrid=document.getElementById('pack-grid');
function renderPacks(){const term=document.getElementById('pack-search').value.toLowerCase();const packs=packNames.filter(p=>p.toLowerCase().includes(term));packGrid.innerHTML=packs.map((p,i)=>`<button class="pack-card" data-pack="${p}"><span>${['✳','◈','▤','⌘','▧'][packNames.indexOf(p)%5]}</span><strong>${p}</strong><small>PACK CATEGORY · PREVIEW</small></button>`).join('')||'<p class="muted">No categories match your search.</p>';packGrid.querySelectorAll('[data-pack]').forEach(b=>b.addEventListener('click',()=>openDialog(b.dataset.pack,'This is a planned collection category. Its contents will be selected from compatible, properly licensed packs and will show author, source, version support and file size.','GOT IT')))}
document.getElementById('pack-search').addEventListener('input',renderPacks);renderPacks();

const dialog=document.getElementById('detail-dialog');
function openDialog(title,body,action='GOT IT'){document.getElementById('dialog-title').textContent=title;document.getElementById('dialog-body').textContent=body;document.getElementById('dialog-action').textContent=action;dialog.showModal()}
document.getElementById('dialog-close').addEventListener('click',()=>dialog.close());
document.getElementById('dialog-action').addEventListener('click',()=>dialog.close());
document.getElementById('play-button').addEventListener('click',()=>openDialog('Launcher engine not connected','This is the clickable UI starter only. It does not contain Minecraft, a Java runtime, Microsoft OAuth, graphics drivers or a game-launch engine yet. These must be integrated into a native Android build.','UNDERSTOOD'));
document.getElementById('world-import').addEventListener('click',()=>openDialog('World import','The native app will request Android storage access and support importing compatible world folders or archives. No files are accessed by this prototype.','OK'));
document.querySelectorAll('[data-setting]').forEach(b=>b.addEventListener('click',()=>{const name=b.dataset.setting;if(name==='Community'){window.open('https://discord.gg/J2YU63MFa','_blank','noopener');return;}const descriptions={"Video and renderer":"Resolution scaling, renderer selection, graphics quality, frame limits and compatible shader settings.","Control customization":"Move, resize and tune touch controls, plus keyboard and controller profiles.","Java environment":"Compatible Java runtimes, recommended memory allocation and advanced JVM arguments.","Downloads and libraries":"Download queues, retries, version manifests, checksums and library repair.","Storage and backups":"Choose game storage, inspect cache usage and manage world restore points.","Microsoft account":"Official Microsoft sign-in flow, Xbox authentication, ownership verification and secure session refresh.","Experimental lab":"Opt-in preview features, diagnostic logs and a one-tap reset for experimental settings.","Language":"Yelp Launcher will be English-only, as requested."};openDialog(name,descriptions[name]||'Settings details will be implemented in the native launcher.','CLOSE')}));

if('serviceWorker' in navigator && location.protocol.startsWith('http')){navigator.serviceWorker.register('./service-worker.js').catch(()=>{});}
