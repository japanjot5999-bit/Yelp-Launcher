# Yelp Launcher — Project Starter 0.2

An original Android-first launcher project, English-only, with a distinctive navy/teal visual system. This package contains:

- `android/` — native Android WebView shell and Gradle project files.
- `web-preview/` — standalone browser prototype.
- `docs/` — technical roadmap, authentication, offline bundle plan, feature inventory and licensing notes.
- `scripts/` — helper to fetch the upstream Amethyst Android source for later engine evaluation.

## What is real today

The browser prototype has working page navigation, sample version selection, catalogue search/filtering, pack-category search, settings detail dialogs, and the user's Discord link. The Android shell loads that prototype from bundled assets and routes HTTPS links to the browser.

## What is not real yet

It cannot launch Minecraft, authenticate a Microsoft account, download Minecraft versions or mods, or include a Java runtime/graphics backend. Those require the native game engine, real API integration, dependency review and device testing.

## Offline-first package strategy

The eventual full distribution can include compatible Java runtime archives and redistributable native graphics/input/audio libraries for supported Android CPU architectures. The package target is **600 MB+ only if real, useful and redistributable components justify that size**. No filler files. Minecraft's proprietary game assets are downloaded after the user signs in and passes ownership verification; mods/resource packs are obtained from permitted sources.

## Build setup

See `android/README.md`. Build requires Android SDK Platform 36, JDK 17, Android Gradle Plugin 9.4.1 and Gradle 9.6.0. The included `android/gradlew` bootstrap helper obtains Gradle 9.6.0 if needed; the Android SDK must still be installed. The project source is not itself an APK.

## Upstream engine candidate

Amethyst Android is the candidate engine foundation. Its public README documents Android Java Edition support, Forge/Fabric support, a pre-built multi-architecture JRE CI artifact, and a Gradle build task. Its project is LGPLv3; review the full source and dependency licences before redistribution or modification. See `docs/ENGINE_INTEGRATION.md`.
